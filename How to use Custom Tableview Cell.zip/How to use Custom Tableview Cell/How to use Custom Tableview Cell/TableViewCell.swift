//
//  TableViewCell.swift
//  How to use Custom Tableview Cell
//
//  Created by Abhishek Verma on 19/07/17.
//  Copyright © 2017 Abhishek Verma. All rights reserved.
//

import UIKit

class TableViewCell: UITableViewCell {

    @IBOutlet weak var TitleLabel: UILabel!
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
